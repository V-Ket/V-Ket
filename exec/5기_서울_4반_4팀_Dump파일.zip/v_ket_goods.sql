-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 13.125.53.163    Database: v_ket
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods` (
  `goods_id` bigint NOT NULL AUTO_INCREMENT,
  `goods_content` varchar(255) DEFAULT NULL,
  `goods_img` varchar(255) DEFAULT NULL,
  `goods_name` varchar(255) DEFAULT NULL,
  `goods_price` bigint DEFAULT NULL,
  `goods_quantity` bigint DEFAULT NULL,
  `store_id` bigint DEFAULT NULL,
  PRIMARY KEY (`goods_id`),
  KEY `FKddfqaioer9n24ptytr1gcuwq1` (`store_id`),
  CONSTRAINT `FKddfqaioer9n24ptytr1gcuwq1` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (1,'갤럭시 워치 4 미개봉 새상품..','https://v-ket.s3.ap-northeast-2.amazonaws.com/static/893676e6-b27b-46d1-9d38-b603229706b0%EA%B0%A4%EC%9B%8C%EC%B9%98.jpg','갤럭시워치4',200000,1,1),(2,'갤럭시탭 s7+ 팝니다','https://v-ket.s3.ap-northeast-2.amazonaws.com/static/9cf019d0-18d1-4126-bd19-2209f43ff5f6%EA%B0%A4%EB%9F%AD%EC%8B%9C%ED%83%AD.jpg','갤럭시탭 s7+',600000,1,1),(3,'맛 좋은 수제 유자청 입니다^^','https://v-ket.s3.ap-northeast-2.amazonaws.com/static/91df6f71-6c5c-416e-b952-24144ba998c4%EC%9C%A0%EC%9E%90%EC%B2%AD.jpg','수제 유자청',20000,9,2),(4,'맛 좋은 수제 라임청 입니다^^','https://v-ket.s3.ap-northeast-2.amazonaws.com/static/3111ced8-0462-4f36-9e02-1f442d075e84%EB%9D%BC%EC%9E%84%EC%B2%AD.jpg','수제 라임청',20000,9,2),(5,'맛 좋은 수제 레몬청 입니다^^','https://v-ket.s3.ap-northeast-2.amazonaws.com/static/7bff3837-6d2e-46b0-8d82-4c47a1af30d5%EB%A0%88%EB%AA%AC%EC%B2%AD.jfif','수제 레몬청',20000,10,2),(6,'맛 좋은 수제 자몽청 입니다^^','https://v-ket.s3.ap-northeast-2.amazonaws.com/static/d23ec33f-d7e4-41da-a438-f5477f930dd0%EC%9E%90%EB%AA%BD%EC%B2%AD.jpg','수제 자몽청',20000,9,2),(7,'80년 전통의 할매 순대국','https://v-ket.s3.ap-northeast-2.amazonaws.com/static/c62cd09b-546c-443e-a63d-9f2a7064eb6b0GPOSGA.png','순대국',50000,20,3);
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19  9:36:03
