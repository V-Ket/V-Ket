-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 13.125.53.163    Database: v_ket
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` bigint NOT NULL AUTO_INCREMENT,
  `user_character` bigint DEFAULT NULL,
  `user_credit` bigint DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (6,-1,240000,'ssafy','ssafy','{bcrypt}$2a$10$hnFFJqR0yONEa4XTs5ZKSe/VeR.3l2w1/WiQmt4eM9TQHKLXxf1qW','01000000000'),(7,-1,120000,'ssafyFood','ssafyFood','{bcrypt}$2a$10$/UVRqeKOCygKlDZnCen6EudZHnCohMrlBmSU6GwjnP.IHZhZHRtJq','01000000000'),(8,-1,0,'asya390','녹쌕','{bcrypt}$2a$10$MSwJ3C3AurWDMxDC07jCOOdtBldQAeWlywAC0NCHXTZ1WUO1tYFqO','01066892398'),(9,-1,0,'ssafyFas','ssafyFas','{bcrypt}$2a$10$SCxKOn0BFCn1tHARB348QO21PCVbbfHTmAbtxo75WT4ZTkV/z2mwe','01000000000'),(10,-1,0,'ssafyKids','ssafyKids','{bcrypt}$2a$10$bc/FYsfAAJU8/fwdJjy0meCRtCbZiY6bMsScB.jKAnPU0VZKVBCS.','01000000000'),(11,-1,0,'ssafyIT','ssafyIT','{bcrypt}$2a$10$nSsuaOWjw5f2s/qqokjw7OdbWlEuGRi2Rp9ZGbXPrIdHKUinHXOZ2','01000000000'),(12,-1,0,'양마시아','양마시아','{bcrypt}$2a$10$2rk/5pzaQ8LxJsr9351AIO.qrcnpJVnk0q1HdNYHY6BGqMIydToWG','01011111111'),(13,-1,100000,'jeus1112','나에게키보드만있었더라면','{bcrypt}$2a$10$wnkdECdqEXQ84r/MkZ.L1.duXoNROwgWyCqjgJaSTrCAGqcPHmW8K','01012345678'),(14,-1,0,'choozx','씁하','{bcrypt}$2a$10$/qg4vvDeKjiC9tuINTYoU.3X4y6u6qUCZi51fwjufULJB.tsawjFC','01071922785'),(16,-1,0,'jwjw6','jwjw6','{bcrypt}$2a$10$LID1OYt3/IrTYAuIXmfCI.0DGnFnlfiNw7TcsT/Jifcucn69m0.yy','01011112222'),(17,-1,0,'jwjw7','jwjw7','{bcrypt}$2a$10$BBSEoBJQKGKvu/zGqJ4nu.BAoeAEm/1ov/nHRpRZxT3SmXl0Tzbde','01011112222'),(18,-1,0,'jwjw8','jwjw8','{bcrypt}$2a$10$O3VjC1QuQvZdrAvDVgjevuR/rodtXdfLehb2YVHeYMczv3zbMESii','01011112222'),(19,-1,0,'jwjw9','jwjw9','{bcrypt}$2a$10$axHH5X7HeWxMVXu.rHvQvOyexru/sIMruFFJAB7oCkx1186lHR4AC','01011112222'),(24,-1,0,'jjun','jjun','{bcrypt}$2a$10$/SWR2ZOgjYX/3B5QzrVyJOThGlqbm8z47s3T4pQyM0TrNzZ9Fe43u','01000000000'),(25,-1,0,'fff','fff','{bcrypt}$2a$10$s9iHZaPdE/4JJohewz2eXuybUnRZmU1PnxWlZzgsZFZi8RfjdC046','fff'),(26,-1,0,'bear','bear','{bcrypt}$2a$10$XCR0tntNeWsKtf780KvKYeNQoj5o80PPoAfYinWRTtU6TGDOmtt/W','11'),(27,-1,0,'ssafy123','ssafyking','{bcrypt}$2a$10$W8PoNxB7CJ/L3Y9jZJeE.O6gT1APTKft6ik9PZgt91ViZknYG8XEm','01044774477');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19  9:36:04
