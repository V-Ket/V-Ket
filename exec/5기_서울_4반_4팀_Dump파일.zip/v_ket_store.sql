-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 13.125.53.163    Database: v_ket
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `store_id` bigint NOT NULL AUTO_INCREMENT,
  `store_content` varchar(255) DEFAULT NULL,
  `store_island_num` bigint DEFAULT NULL,
  `store_name` varchar(255) DEFAULT NULL,
  `store_status` bigint DEFAULT NULL,
  `store_url` varchar(255) DEFAULT NULL,
  `island_id` bigint DEFAULT NULL,
  `user_seq` bigint DEFAULT NULL,
  PRIMARY KEY (`store_id`),
  KEY `FKrfrakc1gwe72nc08i575mh1d3` (`island_id`),
  KEY `FKc5j08we1oubaoobyjay5uc22o` (`user_seq`),
  CONSTRAINT `FKc5j08we1oubaoobyjay5uc22o` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`),
  CONSTRAINT `FKrfrakc1gwe72nc08i575mh1d3` FOREIGN KEY (`island_id`) REFERENCES `island` (`island_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES (1,'ssafy 스토어 입니다.',4,'ssafy 스토어',1,NULL,1001,6),(2,'수제로 한땀한땀 만들었어요~\n많은 이용 부탁해요!\n\n화상 요청 전에 채팅으로 먼저 연락 부탁드려요~ open: 09:00 ~ 18:00\n',5,'ssafy Food',1,'https://k5a404.p.ssafy.io',1002,7),(3,'3대전통맛집',6,'할매순대',1,'https://k5a404.p.ssafy.io',1002,13),(4,'양마시아의 상점입니다',3,'양마시아',0,'https://k5a404.p.ssafy.io',1001,12),(5,'싸피 전자 상가 문의 02-1231-4523',9,'싸피 전자 상가',0,'https://k5a404.p.ssafy.io',1001,10),(8,'안녕하세요 하이 싸피 마트 입니다.',1,'하이 싸피 마트',1,'https://k5a404.p.ssafy.io',1001,16),(9,'옆집보다 쌉니다^^',5,'옆집보다 싸요',1,'https://k5a404.p.ssafy.io',1001,17),(10,'아크로폴리의 상점입니다.',6,'아크로폴리',0,'https://k5a404.p.ssafy.io',1001,18),(11,'오늘은 빵이 없어요ㅜㅜ',8,'싸피바게트',0,'https://k5a404.p.ssafy.io',1002,19);
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19  9:36:04
